<?php
/**
 * FVE Monitor — hlavní konfigurace
 *
 * Tento soubor patří MIMO git (.gitignore).
 * Po nasazení nakopírovat z config.example.php a vyplnit reálné hodnoty.
 */

return [
    // ── Databáze ────────────────────────────────────────────
    'db' => [
        'host'    => '127.0.0.1',
        'port'    => 3306,
        'unix_socket' => '/var/run/mysqld/mysqld.sock',
        'name'    => 'fve_monitor',
        'user'    => 'fve_monitor',
        'pass'    => 'kokotkokot1236',
        'charset' => 'utf8mb4',
    ],

    // ── iSolarCloud (Sungrow) ───────────────────────────────
    // Pokud nemáš klíče, nech 'mock' a systém poběží na simulovaných datech.
    // Po obdržení klíčů přepni 'driver' na 'isolarcloud'.
    'isolarcloud' => [
        'driver'      => 'isolarcloud', // 'mock' | 'isolarcloud'
        'base_url'    => 'https://gateway.isolarcloud.eu', // EU region
        'app_key'     => '',
        'access_key'  => '', // hodnota hlavičky x-access-key
        'username'    => '',
        'password'    => '',
        // RSA public key pro šifrování hesla (Sungrow ti ho pošle s AppKey)
        'rsa_public_key' => '',
    ],

    // ── PVGIS (zdarma, bez klíče) ────────────────────────────
    'pvgis' => [
        'base_url'      => 'https://re.jrc.ec.europa.eu/api/v5_3',
        'radiation_db'  => 'PVGIS-SARAH3', // pro EU
        'cache_days'    => 30, // jak často refreshovat
    ],

    // ── Dashboard ────────────────────────────────────────────
    'app' => [
        'name'           => 'FVE Monitor',
        'timezone'       => 'Europe/Prague',
        'underperform_threshold' => 0.70, // pokud actual/expected < 70 % → alert
        'log_dir'        => __DIR__ . '/../logs',
    ],
    'admin' => [
        'username'      => 'admin',
        'password_hash' => '$2y$10$7GWf.L0jwhwtMEuxAPJfHO25XgA7dpjnvnCcVStnXkrMH.m9SDr8S',
    ],
    'isolarcloud' => [
        'driver'      => 'isolarcloud',
        'base_url'    => 'https://gateway.isolarcloud.eu',
        'app_key'     => 'D2A6FCFDBF6D56E54ECFEE2876EC391A',
        'access_key'  => '5xv38qef16n8gckdq9ftnyjem1gsmse3',
        'username'    => 'jaluvkadavid@gmail.com',
        'password'    => 'Klavesnice1236.',
        'rsa_public_key' => <<<'PEM'
-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCvNTPZOC+ksgfDlhcLxR98sSIa
JrBlqbnH/86Wh7Ecz26kxhkQhu5Il5k+qAsMiB7jEZCtpgxw1QwALGerFqBQGhMp
kHbmnSI18eARQFaItilzYXGIItPxUKFF1UOknl5F9J93efLZTFqVuA/2r3XC04Ht
xewOa5BYC740wq/fcQIDAQAB
-----END PUBLIC KEY-----
PEM,
    ],
    'solaredge' => [
        'driver'   => 'solaredge',
        'base_url' => 'https://monitoringapi.solaredge.com',
        'api_key'  => '',  // doplníš až bude klíč aktivní
    ],
    // === VAPID (Web Push) ===
    'vapid' => [
        'public_key'  => 'BPv0o-ri0BVFodYoeQzhJUkyrhI7RPDi4H6UCxKRiULsl2VcVIdOKK_kxZzdGJKWp-45Bt2sO0azT5L6KqO4Dp0',
        'private_key' => 'vdM-ygObjV8j-Dfzfrr77iWohktCjQPBNrL1klBjPhA',
        'subject'     => 'mailto:admin@sunlai.org',
    ],
];
